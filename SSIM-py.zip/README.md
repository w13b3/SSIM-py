# SSIM-py

Install packages in requirement.txt: `pip install -r requirements.txt`

For more information use: `python SSIM-py.zip --help`

---

https://github.com/w13b3/SSIM-py
